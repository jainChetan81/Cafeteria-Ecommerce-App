module.exports = {
    mongoURI:
        "mongodb+srv://chetan:abc123abc@cluster0.wrxel.mongodb.net/development?retryWrites=true&w=majority",
    cookie: "coolboy",
    stripePublishableKey:
        "pk_test_51Gwo8zFD9wPnB6pJHuxKtGDmoy5txxWlJTy3u9t1Gbval5VwMj6L3W7JpejaBd5LvCNX5jMVhv19EPM4GDWb4c2C00RdfkkhTc",
    stripeSecretKey:
        "sk_test_51Gwo8zFD9wPnB6pJMG06qH9NttfyB220oLkxX2s4zrSO2mBC3xiOPGEIPAZyjgmDKCKniqFUEp2NGWcSkcxLoN2a00ZjpeNRmq",
    jwtKey: "CHETAN_SECRET_KEY",
};

// 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
